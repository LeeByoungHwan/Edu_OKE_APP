﻿import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class OracleConnect {
 public static void main(String[] args) throws Exception {
	 
	 
	 
	 String user = "HSDE_POC";
	 String pw = "HadeDwPoc789#_";
	 String url = "jdbc:oracle:thin:@130.61.117.35:1521/hsdbcs_pdb1.dbsubnet.hsdevcn.oraclevcn.com";
	 Connection conn = null;
	 Class.forName("oracle.jdbc.driver.OracleDriver");
	 
	 conn = DriverManager.getConnection(url, user, pw);
	 System.out.println("성공");
	 
	 String str_qry = "SELECT SYSDATE FROM DUAL";
	 
	 Statement stmt = conn.createStatement();
	 ResultSet rs  = stmt.executeQuery(str_qry);
	 
	 while (rs.next()) {
             System.out.println("결과 값:" + rs.getString(1));
     }
     
	 
 }
 
 
}
